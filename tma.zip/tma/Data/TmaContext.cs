using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using tma.Models;

namespace tma.Data
{
    public class TmaContext : DbContext
    {
        public TmaContext(DbContextOptions<TmaContext> options) : base(options)
        {
        }

        public DbSet<TaskModel> tbtask { get; set; }
    }

}