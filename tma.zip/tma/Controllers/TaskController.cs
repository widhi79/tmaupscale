
using Microsoft.AspNetCore.Mvc;
using tma.Data;
using tma.Models;

namespace tma.controllers
{
    public class TaskController : Controller
    {
        private readonly TmaContext _context;

        public TaskController(TmaContext context)
        {
            _context = context;
        }

        /*public IActionResult Index()
        {
            // Retrieve tasks from the data source
            List<TaskModel> tasks = _context.tbtask.ToList(); // Assuming tbtask is your DbSet in TmaContext

            // Pass the list of tasks to the view
            return View(tasks);
        }*/
        public IActionResult Index(string searchString, string sortOrder)
        {
            IQueryable<TaskModel> tasks = _context.tbtask.AsQueryable();

            // Filtering
            if (!string.IsNullOrEmpty(searchString))
            {
                tasks = tasks.Where(t =>
                    t.Title.Contains(searchString) ||
                    t.Description.Contains(searchString)
                );
            }
            // Sorting
            switch (sortOrder)
            {
                case "title_asc":
                    tasks = tasks.OrderBy(t => t.Title);
                    break;
                case "title_desc":
                    tasks = tasks.OrderByDescending(t => t.Title);
                    break;
                case "duedate_asc":
                    tasks = tasks.OrderBy(t => t.DueDate);
                    break;
                case "duedate_desc":
                    tasks = tasks.OrderByDescending(t => t.DueDate);
                    break;
                default:
                    tasks = tasks.OrderBy(t => t.Id);
                    break;
            }

            // Set ViewBag for current sort order
            ViewBag.CurrentFilter = searchString;
            ViewBag.CurrentSort = sortOrder;

            // Pass the filtered and sorted tasks to the view
            return View(tasks.ToList());
        }


        public IActionResult FrmTask()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult FrmTask(TaskModel task)
        {
            if (ModelState.IsValid)
            {
                // Save the new task to the database
                _context.tbtask.Add(task);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(task);
        }

        public IActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            var task = _context.tbtask.Find(id);

            if (task == null)
            {
                return NotFound();
            }

            _context.tbtask.Remove(task);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var task = _context.tbtask.Find(id);

            if (task == null)
            {
                return NotFound();
            }

            return View(task);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(TaskModel task)
        {
            if (ModelState.IsValid)
            {
                _context.tbtask.Update(task);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(task);
        }

        [HttpPost]
        public IActionResult EditIsCompleted(int id, bool isCompleted)
        {
            var task = _context.tbtask.Find(id);

            if (task == null)
            {
                return NotFound();
            }

            task.IsCompleted = isCompleted;
            _context.tbtask.Update(task);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }


    }
}