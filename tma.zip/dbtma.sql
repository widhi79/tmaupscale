/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 8.0.25 : Database - dbtma
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbtma` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `dbtma`;

/*Table structure for table `tbtask` */

DROP TABLE IF EXISTS `tbtask`;

CREATE TABLE `tbtask` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text,
  `description` text,
  `duedate` datetime DEFAULT NULL,
  `priority` int DEFAULT '0',
  `iscompleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `tbtask` */

insert  into `tbtask`(`id`,`title`,`description`,`duedate`,`priority`,`iscompleted`) values 
(1,'coba','percobaan awal','2023-06-30 00:00:00',0,0),
(3,'test','soal test','2023-07-01 00:00:00',1,1),
(4,'fixrequire','perbaikan fitur','2023-07-01 00:00:00',2,0),
(6,'task testing 5','task segera berakhir','2023-07-04 00:00:00',1,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
