
using System.ComponentModel.DataAnnotations;

namespace tma.Models
{
    public class TaskModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Judul Wajib Diisi.")]
        public string? Title { get; set; }

        [Required(ErrorMessage = "Deskripsi Wajib Diisi.")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "Tanggal Batas Akhir Wajib Diisi")]
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }

        [Required(ErrorMessage = "Prioritas Wajib Diisi.")]
        public Priority Priority { get; set; }
        public bool IsCompleted { get; set; }
    }

    public enum Priority
    {
        Low,
        Medium,
        High
    }
}